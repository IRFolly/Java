public interface Despesa {

    public void cadastraDespesa(String despesa);
}
