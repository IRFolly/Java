public interface Venda {

    public void fechaVenda(double valorVenda);
}
