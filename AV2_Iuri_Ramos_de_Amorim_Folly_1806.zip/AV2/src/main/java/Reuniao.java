public interface Reuniao {

    public void agendaReuniao(String motivo);

}
